<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>TranslateController</name>
    <message>
        <location filename="main.cpp" line="39"/>
        <source>---Language changed to Chinese</source>
        <translation>语言变更为中文</translation>
    </message>
    <message>
        <location filename="main.cpp" line="44"/>
        <source>---Language changed to English</source>
        <translation>语言变更为英文</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="11"/>
        <source>MainWindow</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <location filename="main.qml" line="22"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="main.qml" line="27"/>
        <source>English</source>
        <translation>英文</translation>
    </message>
    <message>
        <location filename="main.qml" line="38"/>
        <source>Chinese</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="main.qml" line="81"/>
        <source>This is &quot;Test Text&quot;</source>
        <translation>这是测试文本</translation>
    </message>
    <message>
        <location filename="main.qml" line="87"/>
        <source>Change Language</source>
        <translation>切换语言</translation>
    </message>
</context>
</TS>
